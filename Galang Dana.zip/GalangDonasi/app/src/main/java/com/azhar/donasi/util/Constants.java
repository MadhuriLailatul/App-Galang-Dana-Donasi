package com.azhar.donasi.util;

public class Constants {
    public static final String DONASI_KEMANUSIAAN = "Kemanusiaan";
    public static final String DONASI_TANAMAN = "Tanaman";
}
